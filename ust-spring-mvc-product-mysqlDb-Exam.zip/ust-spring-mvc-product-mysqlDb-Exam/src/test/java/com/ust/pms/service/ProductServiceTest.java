package com.ust.pms.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pms.ust.controller.AbstractTest;
import com.ust.pms.model.Product;
import com.ust.pms.repository.ProductRepository;

class ProductServiceTest extends AbstractTest{

	@Autowired
	private ProductRepository productRepository;

	private Product product;

	@BeforeEach
	public void setUp() {

		product = new Product(125, "WaterBottle", 100, 400);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void testSaveProduct() {

		/*
		 * Product product=new Product(); product.setPrice(100);
		 * product.setProductid(125); product.setProductname("light");
		 * product.setQuantityOnHand(38);
		 */
		productRepository.save(product);
		Product result = productRepository.findById(product.getProductid()).get();
		System.out.println("product   " + product);
		assertEquals(125, result.getProductid());

	}

	@Test
	public void testDeleteProduct() {
		Product product = new Product(122, "Lays", 100, 400);
		productRepository.save(product);
		productRepository.deleteById(product.getProductid());
		Optional<Product> deleteProduct = productRepository.findById(product.getProductid());
		assertEquals(Optional.empty(), deleteProduct);

	}

	@Test
	public void testUpdateProduct() {

		product.setQuantityOnHand(30);
		productRepository.save(product);
		Product result = productRepository.findById(product.getProductid()).get();
		System.out.println("product   " + product);
		assertEquals(125, result.getProductid());

	}

	@Test
	public void testIsProductExist() {

	}

}
