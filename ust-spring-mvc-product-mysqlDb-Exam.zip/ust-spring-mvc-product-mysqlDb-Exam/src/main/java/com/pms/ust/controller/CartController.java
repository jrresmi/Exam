package com.pms.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.CartTable;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;

@RestController

public class CartController {
	
 @Autowired
 ProductService productService;
 
 @Autowired
 CartService cartservice;
	 
 //public ModelAndView updateProductWithId("update/{productid}") {
 @RequestMapping("/update/{productid}")
 public ModelAndView updateProductWithId(@PathVariable("productid") String productid) {
	
ModelAndView m=new ModelAndView();
	 int pId=Integer.parseInt(productid);
	 Product product = productService.getProductwithId(pId);
	 m.addObject("command", product);
	 m.setViewName("editProduct");
	return m;
	 
 }
		
	
 
 @RequestMapping(value="/editSave",method = RequestMethod.POST)    
 public ModelAndView editsave(@ModelAttribute("product") Product product){    
	 ModelAndView modelandview=new ModelAndView();
     productService.updateProduct(product);   
    modelandview.addObject("updatemsg", "product updated successfully");
    return new ModelAndView("updateProduct","updatemsg", "product updated successfully");
    
 }    
 
 @RequestMapping("/update")
 public ModelAndView updatePrWithId() {
	 
	 return new ModelAndView("updateProductWithId","command",new Product());
	
		
	}
	


@RequestMapping("/deleteFromCart/{cartId}")
public ModelAndView deleteCart(@PathVariable("cartId") String cartId,Model model) {
	Integer cid=new Integer(cartId);
	cartservice.deleteProductFromCart(cid);
	model.addAttribute("deletemsg", "Product is deleted form your cart");
	ModelAndView modelAndView=new ModelAndView();
	modelAndView.addObject("cartId",cartId);
	return new ModelAndView("deleteCart");
}	 
	
}