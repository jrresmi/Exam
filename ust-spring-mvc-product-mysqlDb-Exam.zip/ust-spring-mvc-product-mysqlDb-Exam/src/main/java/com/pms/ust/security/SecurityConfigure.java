package com.pms.ust.security;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

import com.ust.pms.service.MyUserDetailService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@EnableWebSecurity
public class SecurityConfigure extends WebSecurityConfigurerAdapter {
	
	@Autowired
	DataSource datasource;
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{
	authenticationManagerBuilder.jdbcAuthentication().dataSource(datasource);
}

	
	
/*
 * public void configure(AuthenticationManagerBuilder auth) throws Exception {
 * auth.inMemoryAuthentication()
 * .withUser("resmi").password("resmi").authorities("ROLE_ADMIN").and()
 * .withUser("ust").password("ust").authorities("ROLE_USER").and()
 * .withUser("global").password("global1").authorities("ROLE_ADMIN","ROLE_USER")
 * ; }
 */
	
	
	@Override
	
		protected void configure(HttpSecurity http) throws Exception {
			// TODO Auto-generated method stub
		http.authorizeRequests()
		.antMatchers("/register").permitAll()
		.antMatchers("/").permitAll()
		.antMatchers("/index").hasAnyRole("USER","ADMIN")
		.antMatchers("/viewAllProducts").hasAnyRole("USER","ADMIN")
				.antMatchers("/addproduct").hasAnyRole("ADMIN")
				.antMatchers("/showCart").hasAnyRole("USER")
			.anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll().and().logout().permitAll();
				
		
		http.csrf().disable();
		}
	
	@Bean
	public PasswordEncoder PasswordEncoder() {
		return  NoOpPasswordEncoder.getInstance();
				}
	
	@Bean
	public JdbcUserDetailsManager JdbcUserDetailsManager() {
		JdbcUserDetailsManager jdbcUserDetailsManager=new JdbcUserDetailsManager();
		jdbcUserDetailsManager.setDataSource(datasource);
		return jdbcUserDetailsManager;
				
	}
	

}
