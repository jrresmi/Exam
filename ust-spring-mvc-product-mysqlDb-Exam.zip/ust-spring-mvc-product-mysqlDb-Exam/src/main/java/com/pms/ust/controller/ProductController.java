package com.pms.ust.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.CartTable;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;
import com.ust.pms.service.CartService;
import com.ust.pms.service.EmailService;
import com.ust.pms.service.ProductService;

@Controller
//@RestController
public class ProductController {
	
	@Autowired
	ProductService productservice;
	@Autowired
	CartService cartService;
	@Autowired
	EmailService emailService;
	@RequestMapping(value = "/sendemail")
	   public String sendEmail() throws AddressException, MessagingException, IOException {
		emailService.sendmail();
	      return "Email sent successfully";
	   }  
	
		
	@RequestMapping("/addProduct")
	public ModelAndView addproduct() {
		return new ModelAndView("addproduct","command",new Product());
		//return "addproduct";
	}

	@RequestMapping("/saveproduct")
	public String saveproduct(Product product) {
		productservice.saveProduct(product);
			return "success";
	
	}
	@RequestMapping("/serchProductById")
	public ModelAndView searchProductById(Product product) {
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("serchProductByIdForm");
		int pId=product.getProductid();
		if(productservice.isProductExists(pId)) {
			Product productDetails=productservice.getProductwithId(pId);
			modelAndView.addObject("command", productDetails);
		}
		else {
			modelAndView.addObject("command", new Product());
			modelAndView.addObject("msg","product with productId : "+pId);
		}
		return modelAndView;
		//return new ModelAndView("serchProductById","command",new Product());
	}
	
	//@RequestMapping("/serchProductById")
	@RequestMapping("/serchProductByIdForm")
	public ModelAndView searchProductByIdForm() {
		return new ModelAndView("serchProductById","command",new Product());
		
	}
	
	
	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("serchProductById");
		modelAndView.addObject("command", new Product());
		int pId=product.getProductid();
		if(productservice.isProductExists(pId)) {
			productservice.deleteProduct(pId);
			modelAndView.addObject("msg","product with productId : "+pId +"deleted");
		}
		else {
			
			modelAndView.addObject("msg","product with productId : "+pId + "does not existed");
		}
		return modelAndView;
		//return new ModelAndView("serchProductById","command",new Product());
	}
	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products =productservice.getProducts();
		//System.out.println(" My product list is  "+ products);
		return new ModelAndView("viewAllProducts","products",products);
	}
	
	
	
@RequestMapping("/delete/{productid}")
	public ModelAndView deleteCart(@PathVariable("productid") String productid) {
		Integer pid=new Integer(productid);
		productservice.deleteProduct(pid);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("productid",productid);
		return new ModelAndView("viewAllProducts");
		 
		
	}	 
@RequestMapping("/cart/{productid}")

public ModelAndView addToCart(@PathVariable("productid") int productid,Model model) {
	int itemCountInCart=0;
	int quantity=1;
	
	Product product= productservice.getProductwithId(productid);
	
	String username=cartService.getUsername();
	if(cartService.countByName(username)<10 && product.getQuantityOnHand()!=0) {
		
	CartTable cart = new CartTable();
	cart.setProductid(product.getProductid());
	cart.setProductname(product.getProductname());
	cart.setStatus(true);
	cart.setQuantity(quantity);
	cart.setPrice(product.getPrice());
	cart.setTotalAmount(quantity*product.getPrice());
	cart.setUsername(username);
	cartService.saveToCart(cart);
	itemCountInCart=cartService.countByName(username);
	if(product.getQuantityOnHand()!=0) {
		int newQuantity=product.getQuantityOnHand()-1;
		product.setQuantityOnHand(newQuantity);
		productservice.saveProduct(product);
		
		model.addAttribute("message"," ** Product successfully added to cart..Thanks ** ");
	}
	}
	else {
		model.addAttribute("message"," ** You cannot add more than 10 products to your cart ** ");
	}
	List<Product> productList= productservice.getProducts();
	ModelAndView modelandview=new ModelAndView();
	modelandview.setViewName("cart");
	modelandview.addObject("productList",productList);
	modelandview.addObject("itemCountInCart",itemCountInCart);
	return modelandview;
}


@RequestMapping("/showCart")

public ModelAndView showCart() {
	BigDecimal totalAmount=null;
	
	
	String username=cartService.getUsername();
	totalAmount=cartService.grantTotal(username);
	List<CartTable> myCartItems=cartService.getListByUser(username);
	System.out.println(" showcart user name is  "  + cartService.getUsername());
	System.out.println("my myCartItems   " + myCartItems);
	
	ModelAndView modelandview=new ModelAndView();
	modelandview.setViewName("myCart");
	modelandview.addObject("myCartItems",myCartItems);
	
	if(totalAmount!=null) {
		modelandview.addObject("totalAmount", totalAmount);
	}
	else {
		modelandview.addObject("totalAmount", 0);
		modelandview.addObject("totalmsg", "Cart is emplty");
	}
	return modelandview;
	
}

}
