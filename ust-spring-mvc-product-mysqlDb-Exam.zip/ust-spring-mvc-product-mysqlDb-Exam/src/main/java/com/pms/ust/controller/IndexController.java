package com.pms.ust.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Numbers;
import com.ust.pms.model.Product;
import com.ust.pms.model.UserRegistration;
import com.ust.pms.service.EmailService;
import com.ust.pms.service.MyNumberService;

@Controller
//@RestController
public class IndexController {
	@Autowired
	MyNumberService mynumberservice;
	@Autowired
	EmailService emailService;
	
	@RequestMapping("/index")
		public String index() {
		System.out.println("inside index page");
		return "index";
	}
	@RequestMapping("/")
	public ModelAndView index1() throws AddressException, MessagingException, IOException {
		String username =null;
		Object principal=SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
			System.out.println("My username is    "+username);
		}
		
		ModelAndView view=new ModelAndView();
		view.addObject("username", username);
		view.setViewName("index");
		//to sent mail
		
		try {
			emailService.sendmail();
			view.addObject("mailmsg", "Notification mail successfully sent");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
	
		return view; 
		
	}
	
	
	@RequestMapping("/addnumber")
			public String addNumber() {
			return "addnumbers";
			}
	
	@RequestMapping("/result")
	public ModelAndView result(Numbers number) {
		int res=number.getFirstNumber()+number.getSecondNumber();
		number.setResult(res);
		mynumberservice.saveNumber(number);
		System.out.println("sum is "+ res);
		System.out.println("first no " + number.getFirstNumber());
		System.out.println("second no " +number.getSecondNumber());
		
		
		return new ModelAndView("result","sumresult",res);
	}		
		
		
	

	@RequestMapping("/resmi")
	public String index2() {
		return "ma";
	}
	
	@RequestMapping(value = "/login" ,method = RequestMethod.GET)
public String login(Model model,String error,String logout) {
		if(error!=null) {
			model.addAttribute("errormsg","your name or pass is incorrect");
			
		}
		
		if(logout!=null) {
			model.addAttribute("msg", "successfully logged out");
			
		}
		
		
		return "login";
	}
	@RequestMapping(value = "/register" ,method = RequestMethod.GET)
	public ModelAndView register() {
		return new ModelAndView("registration","user",new UserRegistration());
	}
	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;
	@RequestMapping(value = "/register" ,method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("user") UserRegistration userRegistration) {
		
		List<GrantedAuthority> authorities=new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		
		User user=new User(userRegistration.getUsername(), userRegistration.getPassword(), authorities);
		jdbcUserDetailsManager.createUser(user);
		return new ModelAndView("login","message","you have successfully registered");
	
		
		
	}
}
