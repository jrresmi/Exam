package com.ust.pms.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.pms.ust.controller.CartController;
import com.ust.pms.model.CartTable;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;

@Service
public class CartService {
	
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	ProductService productService;
	
	 
	/*
	 * public void saveToCart(String productid,CartTable cartTable) {
	 * cartRepository.save(cartTable);
	 * 
	 * 
	 * }
	 */
	
	public void deleteProductFromCart(Integer cartId) {
    	cartRepository.deleteById(cartId);
		
	}
	
	public void saveToCart(CartTable cartTable) {
		cartRepository.save(cartTable);
		
	
	}
	
	public List<CartTable> searchProductwithUser(String username){
		List<CartTable> cartItems=new ArrayList<>();
		//cartItems=cartRepository.findByUsername(username);
		cartRepository.findByUsername(username).forEach(cartItems::add);
		//System.out.println("cartItems  "+cartItems.toString());
		return cartItems;
	}
	
	public List<CartTable> getListByUser(String username){
		List<CartTable> cartItems=new ArrayList<>();
		cartItems=cartRepository.findByUsername(username);
		return cartItems;
	}
	
	public String getUsername() {
		String username=null;
		Object principal=SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
			System.out.println(" My username is  "+ username);
					
		}
		
	
		return username;
	}
	
	public Integer countByName(String username) {
	return	cartRepository.countByUsername(username);
	}
	
	public long itemCount(){
		return	cartRepository.count();
		}
	public Long sumQuantities() {
		return cartRepository.sumQuantities();
	}

	
	public BigDecimal grantTotal(String username) {
		return cartRepository.sumPrice(username);
	}
		
	public CartTable update(CartTable cartTable) {
		return cartRepository.save(cartTable);
	}
}
