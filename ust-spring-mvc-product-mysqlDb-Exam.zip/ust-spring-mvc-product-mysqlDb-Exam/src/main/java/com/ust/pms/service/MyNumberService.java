package com.ust.pms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Numbers;
import com.ust.pms.repository.MyNumberRepository;

@Service
public class MyNumberService {
	@Autowired 
	 MyNumberRepository mynumberrepository;
	public void saveNumber(Numbers number) {
		mynumberrepository.save(number);
	}

}
