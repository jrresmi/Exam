package com.ust.pms.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product implements Serializable{


@Id
	private  @NotNull int productid;
	private String productname;
	private int  quantityOnHand;
	private int price;
	//private int quantitySelected;
	//private String username;
	
	
	
	
	
	
}
