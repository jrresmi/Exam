package com.ust.pms.model;

import javax.persistence.Id;

import lombok.Data;

@Data

public class UserRegistration {
	@Id
	private String username;
	private String customerName;
private String repeatPassword;
private String customerAddress;
private long phone;
private int billAmount;

	private String password;

	

}
