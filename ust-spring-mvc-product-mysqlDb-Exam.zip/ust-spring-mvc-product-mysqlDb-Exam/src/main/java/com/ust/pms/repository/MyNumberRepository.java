package com.ust.pms.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ust.pms.model.Numbers;
public interface MyNumberRepository extends CrudRepository<Numbers,Integer>{
	

}
