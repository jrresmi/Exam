package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.CartTable;
import com.ust.pms.model.Product;

public interface  ProductRepository extends CrudRepository<Product, Integer> {

}






