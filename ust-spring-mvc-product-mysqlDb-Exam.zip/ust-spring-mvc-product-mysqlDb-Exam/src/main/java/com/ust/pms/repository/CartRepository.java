package com.ust.pms.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.CartTable;
import com.ust.pms.model.Product;

public interface  CartRepository extends CrudRepository<CartTable, Integer> {
public List<CartTable> findByUsername(String username);
public Integer countByUsername(String username);

@Query(value = "SELECT sum(quantity) FROM CartTable")
public Long sumQuantities();
@Query(value = "SELECT sum(price) FROM CartTable")
public BigDecimal sumPrice(String username);

@Query(value = "SELECT sum(quantity * price) FROM cart_table where username=?1",nativeQuery = true)
public BigDecimal total(String username);
}






