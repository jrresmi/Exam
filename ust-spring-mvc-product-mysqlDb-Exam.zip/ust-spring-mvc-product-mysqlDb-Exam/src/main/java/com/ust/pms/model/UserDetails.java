package com.ust.pms.model;

public class UserDetails {

}
